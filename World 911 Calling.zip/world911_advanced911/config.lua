Config = {}

Config.DispatchTo = 'framework'

Config.Framework = 'esx'
Config.PoliceJobs = {
  'police',
  'sheriff'
}

Config.BlipDurationMs = 30000
Config.BlipSprite = 161
Config.BlipScale = 1.2
Config.BlipColor = 1
Config.BlipName = '911 Call'

Config.CooldownMs = 15000
Config.RequireMessage = true
Config.MaxMessageLength = 200

Config.IncludeCallerName = true
Config.IncludeCallerServerId = true
Config.IncludeStreetName = true
