local function notify(msg)
  TriggerEvent('chat:addMessage', {
    color = { 255, 50, 50 },
    multiline = true,
    args = { '911', msg }
  })
end

RegisterNetEvent('world911:client:notify', notify)

RegisterNetEvent('world911:client:collect911', function(message)
  local ped = PlayerPedId()
  local coords = GetEntityCoords(ped)

  local streetText = nil
  if Config.IncludeStreetName then
    local streetHash, crossHash = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
    local streetName = GetStreetNameFromHashKey(streetHash)
    local crossName = GetStreetNameFromHashKey(crossHash)

    if crossHash ~= 0 and crossName and crossName ~= '' then
      streetText = (streetName or '') .. ' / ' .. (crossName or '')
    else
      streetText = streetName
    end
  end

  TriggerServerEvent('world911:server:submit911', message, { x = coords.x, y = coords.y, z = coords.z }, streetText)
end)

RegisterNetEvent('world911:client:receive911', function(payload)
  local lines = {}

  if payload.message and payload.message ~= '' then
    lines[#lines + 1] = payload.message
  end

  if payload.caller and payload.caller ~= '' then
    lines[#lines + 1] = 'Caller: ' .. payload.caller
  end

  if payload.street and payload.street ~= '' then
    lines[#lines + 1] = 'Location: ' .. payload.street
  end

  notify(table.concat(lines, ' | '))

  if payload.coords then
    local blip = AddBlipForCoord(payload.coords.x + 0.0, payload.coords.y + 0.0, payload.coords.z + 0.0)
    SetBlipSprite(blip, Config.BlipSprite)
    SetBlipDisplay(blip, 4)
    SetBlipScale(blip, Config.BlipScale)
    SetBlipColour(blip, Config.BlipColor)
    SetBlipAsShortRange(blip, false)

    BeginTextCommandSetBlipName('STRING')
    AddTextComponentString(Config.BlipName)
    EndTextCommandSetBlipName(blip)

    CreateThread(function()
      Wait(Config.BlipDurationMs)
      if DoesBlipExist(blip) then
        RemoveBlip(blip)
      end
    end)
  end
end)
