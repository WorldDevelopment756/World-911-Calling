1) Put folder 'world911_advanced911' into your server resources directory.
2) Add to server.cfg:
   ensure world911_advanced911
3) Framework setup:
   - ESX: ensure es_extended before this resource
   - QBCore: ensure qb-core before this resource
4) Config options are in config.lua (blip duration, recipients, jobs).
   - Switch Config.Framework = 'esx' or 'qb'
   - Adjust Config.PoliceJobs list for your server's police job names.
   - Only players with police jobs will receive 911 alerts.
