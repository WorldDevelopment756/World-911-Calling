local lastCallAt = {}

local QBCore = nil
local ESX = nil

CreateThread(function()
  if Config.Framework == 'qb' then
    local ok, core = pcall(function()
      return exports['qb-core']:GetCoreObject()
    end)
    if ok then
      QBCore = core
    end
  elseif Config.Framework == 'esx' then
    local ok, obj = pcall(function()
      return exports['es_extended']:getSharedObject()
    end)
    if ok then
      ESX = obj
    end
  end
end)

local function trim(s)
  return (s:gsub('^%s*(.-)%s*$', '%1'))
end

local function notify(src, msg)
  TriggerClientEvent('world911:client:notify', src, msg)
end

local function isPoliceJob(jobName)
  if not jobName then return false end
  for _, j in ipairs(Config.PoliceJobs or {}) do
    if j == jobName then
      return true
    end
  end
  return false
end

local function isPoliceFramework(src)
  if Config.Framework == 'qb' and QBCore then
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return false end
    local job = Player.PlayerData and Player.PlayerData.job
    local jobName = job and job.name
    return isPoliceJob(jobName)
  end

  if Config.Framework == 'esx' and ESX then
    local xPlayer = ESX.GetPlayerFromId(src)
    if not xPlayer then return false end
    local job = xPlayer.getJob and xPlayer.getJob() or nil
    local jobName = job and job.name
    return isPoliceJob(jobName)
  end

  return false
end

local function shouldReceive911(src)
  if Config.DispatchTo == 'everyone' then
    return true
  end

  if Config.DispatchTo == 'framework' then
    return isPoliceFramework(src)
  end

  if Config.DispatchTo == 'ace' then
    return IsPlayerAceAllowed(src, Config.AcePermission)
  end

  return false
end

RegisterCommand('911', function(source, args)
  local src = source
  if src == 0 then
    return
  end

  local message = trim(table.concat(args or {}, ' '))
  TriggerClientEvent('world911:client:collect911', src, message)
end, false)

RegisterNetEvent('world911:server:submit911', function(message, coords, street)
  local src = source

  local nowMs = GetGameTimer()
  local lastMs = lastCallAt[src] or 0

  if Config.CooldownMs and Config.CooldownMs > 0 and (nowMs - lastMs) < Config.CooldownMs then
    notify(src, 'Please wait before calling 911 again.')
    return
  end

  message = trim(message or '')

  if Config.RequireMessage and message == '' then
    notify(src, 'Usage: /911 [emergency]')
    return
  end

  if Config.MaxMessageLength and #message > Config.MaxMessageLength then
    message = message:sub(1, Config.MaxMessageLength)
  end

  if type(coords) ~= 'table' or coords.x == nil or coords.y == nil or coords.z == nil then
    notify(src, 'Unable to get your location. Try again.')
    return
  end

  lastCallAt[src] = nowMs

  local callerName = GetPlayerName(src) or 'Unknown'
  if Config.IncludeCallerServerId then
    callerName = callerName .. ' [' .. tostring(src) .. ']'
  end

  local payload = {
    message = message,
    coords = { x = coords.x + 0.0, y = coords.y + 0.0, z = coords.z + 0.0 },
    street = Config.IncludeStreetName and (street or nil) or nil,
    caller = Config.IncludeCallerName and callerName or nil,
  }

  notify(src, '911 call sent.')

  for _, pid in ipairs(GetPlayers()) do
    local id = tonumber(pid)
    if id and shouldReceive911(id) then
      TriggerClientEvent('world911:client:receive911', id, payload)
    end
  end
end)

AddEventHandler('playerDropped', function()
  lastCallAt[source] = nil
end)
